# Matrix AI Game Companion

An Android-first Flutter companion with a neon terminal dashboard, provider API connection, permission-gated screen analysis, OCR translation, voice responses, screen recording, and a floating HUD.

## Requirements

- Flutter stable 3.44 or newer with Dart 3.12 or newer
- Android SDK with API 35 installed
- Java 17
- An Android device or emulator; the overlay and screen capture functions require Android

## Run and build

From this folder:

```sh
flutter pub get
flutter run
```

Create a release APK:

```sh
flutter build apk --release
```

The APK is written to `build/app/outputs/flutter-apk/app-release.apk`. To create a Play Store bundle, run `flutter build appbundle --release` and configure a signing key outside the source archive.

## GitHub Actions

The workflow at `.github/workflows/android.yml` builds a release APK on every push and pull request, and can also be started manually from the repository's **Actions** tab. Download the finished APK from the workflow run's **Artifacts** section; the workflow does not publish to the Play Store.

## First-use setup

1. Open **API Terminal** and select Gemini or OpenRouter.
2. Enter a model ID and your own provider API key, then choose **EXECUTE CONNECT & SAVE**. The app sends a small verification request before saving the key.
3. Enable Vision HUD or OCR & Text Translator. Android will show its own screen-sharing consent flow; the app keeps a visible notification while screen access is active.
4. Enable Auto Screen Recorder before recording. Android asks for separate screen-recording consent. The stop action returns the MP4 path.
5. Enter the installed game's Android package name if you want the bottom action to open it, then grant display-over-other-apps permission when prompted.
6. Use the floating HUD: tap for spoken guidance, double-tap to read and translate screen text, and long-press to start or stop a recording.

The AI Mind & Voice panel also accepts a typed question and speaks the response. Text-to-speech uses the device's installed voice engine; Hindi speech quality depends on the Hindi voice installed on that device.

## AI models and API keys

The model ID is editable. The default Gemini model is `gemini-3.8-flash`; the OpenRouter default is `google/gemini-3.8-flash`. Change these to a model actually enabled for your provider account.

The app sends compatible text-and-image requests to Gemini's `generateContent` endpoint and OpenRouter's chat-completions endpoint. It can send a `gemini-1.5-flash` model ID for legacy compatibility, but Google's public Gemini API has retired that model; use a currently supported model for a working Gemini connection. OpenRouter model availability and names are controlled by OpenRouter.

As requested, keys are stored with `shared_preferences` in the app's private Android preferences. This storage is **not encrypted with the Android Keystore**. Anyone with a rooted device, a compromised device, or a debuggable build may be able to recover a saved key. For a public commercial release, replace this credential storage with an encrypted device vault or a server-side proxy; do not bundle a provider key in the APK.

## Android permissions and behavior

- `SYSTEM_ALERT_WINDOW`: Android settings permission required for the floating HUD.
- `FOREGROUND_SERVICE` and `FOREGROUND_SERVICE_MEDIA_PROJECTION`: show persistent, user-visible tasks while screen analysis or recording is active.
- `RECORD_AUDIO`: declared in the manifest, but this build does not record microphone audio.
- `WRITE_EXTERNAL_STORAGE`: declared only through Android 9 (API 28); newer Android versions use scoped storage.
- Screen analysis and recording use separate Android system-consent prompts. The OS can stop screen sharing at any time. Screen capture is unavailable on platforms other than Android.
- Game launch requires the exact installed Android package name; Android returns a clear failure if it cannot find a launchable app.
- Live AI analysis runs every eight seconds while Vision or OCR is enabled and connected. Each call uses the selected provider account and may incur usage or charges.

## Project layout

```text
lib/
  app/                         Theme and app entry
  services/                    Public API and overlay service entry points
  ui/                          Shared dashboard grid entry point
  core/
    services/                  AI, preferences, OCR, capture, overlay, speech
    theme/                     Neon-green dark theme
    widgets/                   Shared neon button
  features/
    connect/                   Provider connection terminal
    dashboard/                 Module matrix, HUD, live status, game target
android/
  app/src/main/                Manifest, Kotlin capture bridge, Android resources
  gradle/                      Gradle wrapper configuration
```

## API references

- Gemini API: https://ai.google.dev/gemini-api/docs
- Gemini model deprecations: https://ai.google.dev/gemini-api/docs/deprecations
- OpenRouter API: https://openrouter.ai/docs/api-reference/overview
package com.matrix.companion

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private lateinit var captureChannel: MethodChannel
    private var pendingCaptureResult: MethodChannel.Result? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        captureChannel = MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            CHANNEL_NAME,
        )
        captureChannel.setMethodCallHandler { call, result ->
            when (call.method) {
                "startCapture" -> requestScreenCapture(result)
                "latestFrame" -> result.success(ScreenCaptureService.latestFrame)
                "stopCapture" -> {
                    stopService(
                        Intent(this, ScreenCaptureService::class.java)
                            .setAction(ScreenCaptureService.ACTION_STOP),
                    )
                    result.success(null)
                }
                "launchGame" -> launchGame(
                    call.argument<String>("packageName"),
                    result,
                )
                else -> result.notImplemented()
            }
        }
    }

    private fun requestScreenCapture(result: MethodChannel.Result) {
        if (ScreenCaptureService.isRunning) {
            result.success(true)
            return
        }
        if (pendingCaptureResult != null) {
            result.error("CAPTURE_BUSY", "A screen permission request is already open.", null)
            return
        }
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE)
            as MediaProjectionManager
        pendingCaptureResult = result
        try {
            startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE)
        } catch (error: Exception) {
            pendingCaptureResult = null
            result.error("CAPTURE_REQUEST_FAILED", error.message, null)
        }
    }

    private fun launchGame(packageName: String?, result: MethodChannel.Result) {
        val targetPackage = packageName?.trim().orEmpty()
        if (targetPackage.isEmpty()) {
            result.error("MISSING_PACKAGE", "Enter the game's Android package name.", null)
            return
        }
        try {
            val launchIntent = packageManager.getLaunchIntentForPackage(targetPackage)
            if (launchIntent == null) {
                result.success(false)
                return
            }
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(launchIntent)
            result.success(true)
        } catch (error: ActivityNotFoundException) {
            result.success(false)
        } catch (error: SecurityException) {
            result.error("GAME_LAUNCH_DENIED", error.message, null)
        }
    }

    @Deprecated("Android activity result callback required by the Flutter Activity host")
    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?,
    ) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_CAPTURE) return

        val callback = pendingCaptureResult
        pendingCaptureResult = null
        if (resultCode != Activity.RESULT_OK || data == null) {
            callback?.success(false)
            return
        }
        val serviceIntent = Intent(this, ScreenCaptureService::class.java)
            .setAction(ScreenCaptureService.ACTION_START)
            .putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
            .putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
            callback?.success(true)
        } catch (error: Exception) {
            callback?.error("CAPTURE_SERVICE_FAILED", error.message, null)
        }
    }

    companion object {
        private const val CHANNEL_NAME = "com.matrix.companion/screen_capture"
        private const val REQUEST_CAPTURE = 7812
    }
}
package com.matrix.companion

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer

class ScreenCaptureService : Service() {
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var workerThread: HandlerThread? = null
    private var worker: Handler? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        createNotificationChannel()
        workerThread = HandlerThread("matrix-screen-capture").also { it.start() }
        worker = Handler(workerThread!!.looper)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> beginCapture(intent)
            ACTION_STOP -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun beginCapture(intent: Intent) {
        try {
            startAsForeground()
            val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
            val resultData = if (Build.VERSION.SDK_INT >= 33) {
                intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
            } ?: throw IllegalStateException("Screen capture permission data is missing.")

            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE)
                as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, resultData)
                ?: throw IllegalStateException("Android did not grant screen capture.")

            projection?.registerCallback(
                object : MediaProjection.Callback() {
                    override fun onStop() {
                        latestFrame = null
                        stopSelf()
                    }
                },
                worker,
            )

            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager)
                .defaultDisplay.getRealMetrics(metrics)
            val width = metrics.widthPixels.coerceAtLeast(1)
            val height = metrics.heightPixels.coerceAtLeast(1)
            val density = metrics.densityDpi.coerceAtLeast(1)

            imageReader = ImageReader.newInstance(
                width,
                height,
                android.graphics.PixelFormat.RGBA_8888,
                3,
            ).also { reader ->
                reader.setOnImageAvailableListener({ source ->
                    val image = source.acquireLatestImage() ?: return@setOnImageAvailableListener
                    try {
                        val now = SystemClock.elapsedRealtime()
                        if (now - lastEncodedAt < FRAME_INTERVAL_MS) {
                            return@setOnImageAvailableListener
                        }
                        lastEncodedAt = now
                        latestFrame = encodeImage(image)
                    } catch (error: Exception) {
                        Log.w(TAG, "Could not encode the latest game frame.", error)
                    } finally {
                        image.close()
                    }
                }, worker)
            }

            virtualDisplay = projection?.createVirtualDisplay(
                "MatrixGameCompanion",
                width,
                height,
                density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader!!.surface,
                null,
                worker,
            )
            if (virtualDisplay == null) {
                throw IllegalStateException("Could not create a virtual display.")
            }
        } catch (error: Exception) {
            Log.e(TAG, "Screen capture startup failed.", error)
            stopSelf()
        }
    }

    private fun encodeImage(image: android.media.Image): ByteArray {
        val plane = image.planes.first()
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val paddedWidth = rowStride / pixelStride
        val padded = Bitmap.createBitmap(
            paddedWidth,
            image.height,
            Bitmap.Config.ARGB_8888,
        )
        val buffer: ByteBuffer = plane.buffer
        buffer.rewind()
        padded.copyPixelsFromBuffer(buffer)
        val cropped = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
        padded.recycle()

        val maxDimension = 1280
        val scale = minOf(
            1.0,
            maxDimension.toDouble() / maxOf(cropped.width, cropped.height),
        )
        val scaled = if (scale < 1.0) {
            Bitmap.createScaledBitmap(
                cropped,
                (cropped.width * scale).toInt().coerceAtLeast(1),
                (cropped.height * scale).toInt().coerceAtLeast(1),
                true,
            ).also { if (it !== cropped) cropped.recycle() }
        } else {
            cropped
        }
        val output = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 76, output)
        scaled.recycle()
        return output.toByteArray()
    }

    private fun startAsForeground() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION,
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        return builder
            .setContentTitle("Matrix AI Game Companion")
            .setContentText("Screen access is active for game analysis.")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < 26) return
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Screen analysis",
            NotificationManager.IMPORTANCE_LOW,
        ).apply {
            description = "Visible indicator while screen analysis is enabled."
        }
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(channel)
    }

    override fun onDestroy() {
        latestFrame = null
        lastEncodedAt = 0L
        isRunning = false
        virtualDisplay?.release()
        imageReader?.setOnImageAvailableListener(null, null)
        imageReader?.close()
        projection?.stop()
        workerThread?.quitSafely()
        virtualDisplay = null
        imageReader = null
        projection = null
        worker = null
        workerThread = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.matrix.companion.START_CAPTURE"
        const val ACTION_STOP = "com.matrix.companion.STOP_CAPTURE"
        const val EXTRA_RESULT_CODE = "screen_capture_result_code"
        const val EXTRA_RESULT_DATA = "screen_capture_result_data"
        private const val CHANNEL_ID = "matrix_screen_capture"
        private const val NOTIFICATION_ID = 7813
        private const val TAG = "MatrixCapture"
        private const val FRAME_INTERVAL_MS = 800L

        @Volatile
        var latestFrame: ByteArray? = null
            private set

        @Volatile
        private var lastEncodedAt: Long = 0L

        @Volatile
        var isRunning: Boolean = false
            private set
    }
}
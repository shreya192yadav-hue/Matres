import 'package:flutter/material.dart';

import '../core/theme/matrix_theme.dart';
import '../features/dashboard/dashboard_screen.dart';

class MatrixApp extends StatelessWidget {
  const MatrixApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Matrix AI Game Companion',
      debugShowCheckedModeBanner: false,
      theme: MatrixTheme.dark,
      home: const DashboardScreen(),
    );
  }
}

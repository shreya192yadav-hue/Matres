import 'dart:convert';

import 'package:http/http.dart' as http;

import 'local_preferences.dart';

class AiService {
  AiService(this._preferences, {http.Client? client})
    : _client = client ?? http.Client();

  static const _geminiBase =
      'https://generativelanguage.googleapis.com/v1beta/models/';
  static const _openRouterUri = 'https://openrouter.ai/api/v1/chat/completions';
  static const _requestTimeout = Duration(seconds: 45);

  final LocalPreferences _preferences;
  final http.Client _client;

  Future<void> testConnection({
    required AiProvider provider,
    required String apiKey,
    required String model,
  }) async {
    final reply = await _generate(
      provider: provider,
      apiKey: apiKey,
      model: model,
      prompt: 'Reply with exactly: MATRIX_LINK_OK',
    );
    if (!reply.toUpperCase().contains('MATRIX_LINK_OK')) {
      throw const AiServiceException(
        'The provider replied, but the connection check did not match.',
      );
    }
  }

  Future<String> analyzeFrame({
    required List<int> jpegBytes,
    required String instruction,
  }) async {
    final (provider, apiKey, model) = _activeCredentials();
    return _generate(
      provider: provider,
      apiKey: apiKey,
      model: model,
      prompt: instruction,
      imageBytes: jpegBytes,
    );
  }

  Future<String> ask(String prompt) async {
    final (provider, apiKey, model) = _activeCredentials();
    return _generate(
      provider: provider,
      apiKey: apiKey,
      model: model,
      prompt: prompt,
    );
  }

  Future<String> translateToHindi(String sourceText) async {
    final trimmed = sourceText.trim();
    if (trimmed.isEmpty) return '';
    return ask(
      'Translate the following on-screen game text from English to Hindi. '
      'Preserve names, numbers, buttons, and short UI labels. '
      'Return only the Hindi translation.\n\n$trimmed',
    );
  }

  (AiProvider, String, String) _activeCredentials() {
    final provider = _preferences.provider;
    final apiKey = _preferences.apiKeyFor(provider);
    if (apiKey.isEmpty) {
      throw const AiServiceException(
        'Connect an API key before using AI features.',
      );
    }
    return (provider, apiKey, _preferences.model);
  }

  Future<String> _generate({
    required AiProvider provider,
    required String apiKey,
    required String model,
    required String prompt,
    List<int>? imageBytes,
  }) async {
    if (apiKey.trim().isEmpty) {
      throw const AiServiceException('Enter an API key to connect.');
    }
    if (model.trim().isEmpty) {
      throw const AiServiceException('Choose a model name.');
    }

    try {
      final response = provider == AiProvider.gemini
          ? await _generateGemini(
              apiKey: apiKey,
              model: model,
              prompt: prompt,
              imageBytes: imageBytes,
            )
          : await _generateOpenRouter(
              apiKey: apiKey,
              model: model,
              prompt: prompt,
              imageBytes: imageBytes,
            );
      if (response.trim().isEmpty) {
        throw const AiServiceException(
          'The provider returned an empty response.',
        );
      }
      return response.trim();
    } on AiServiceException {
      rethrow;
    } catch (error) {
      throw AiServiceException('Request failed: ${_safeError(error)}');
    }
  }

  Future<String> _generateGemini({
    required String apiKey,
    required String model,
    required String prompt,
    List<int>? imageBytes,
  }) async {
    final uri = Uri.parse(
      '$_geminiBase${Uri.encodeComponent(model.trim())}:generateContent',
    ).replace(queryParameters: {'key': apiKey});
    final parts = <Map<String, Object>>[
      {'text': prompt},
      if (imageBytes != null)
        {
          'inline_data': {
            'mime_type': 'image/jpeg',
            'data': base64Encode(imageBytes),
          },
        },
    ];
    final response = await _client
        .post(
          uri,
          headers: const {'Content-Type': 'application/json'},
          body: jsonEncode({
            'contents': [
              {'parts': parts},
            ],
            'generationConfig': {'temperature': 0.4, 'maxOutputTokens': 512},
          }),
        )
        .timeout(_requestTimeout);
    final json = _decodeResponse(response);
    final candidates = json['candidates'];
    if (candidates is List && candidates.isNotEmpty) {
      final content = candidates.first['content'];
      final responseParts = content?['parts'];
      if (responseParts is List) {
        return responseParts
            .where((part) => part is Map && part['text'] is String)
            .map((part) => part['text'] as String)
            .join('\n');
      }
    }
    throw const AiServiceException('Gemini returned no text candidate.');
  }

  Future<String> _generateOpenRouter({
    required String apiKey,
    required String model,
    required String prompt,
    List<int>? imageBytes,
  }) async {
    final content = <Map<String, Object>>[
      {'type': 'text', 'text': prompt},
      if (imageBytes != null)
        {
          'type': 'image_url',
          'image_url': {
            'url': 'data:image/jpeg;base64,${base64Encode(imageBytes)}',
          },
        },
    ];
    final response = await _client
        .post(
          Uri.parse(_openRouterUri),
          headers: {
            'Authorization': 'Bearer $apiKey',
            'Content-Type': 'application/json',
            'X-Title': 'Matrix AI Game Companion',
          },
          body: jsonEncode({
            'model': model.trim(),
            'messages': [
              {'role': 'user', 'content': content},
            ],
            'temperature': 0.4,
            'max_tokens': 512,
          }),
        )
        .timeout(_requestTimeout);
    final json = _decodeResponse(response);
    final choices = json['choices'];
    if (choices is List && choices.isNotEmpty) {
      final messageContent = choices.first['message']?['content'];
      if (messageContent is String) return messageContent;
      if (messageContent is List) {
        return messageContent
            .where((part) => part is Map && part['text'] is String)
            .map((part) => part['text'] as String)
            .join('\n');
      }
    }
    throw const AiServiceException('OpenRouter returned no text choice.');
  }

  Map<String, dynamic> _decodeResponse(http.Response response) {
    dynamic decoded;
    try {
      decoded = jsonDecode(utf8.decode(response.bodyBytes));
    } on FormatException {
      throw AiServiceException(
        'The provider returned an unreadable response (${response.statusCode}).',
      );
    }
    if (response.statusCode < 200 || response.statusCode >= 300) {
      String? detail;
      if (decoded is Map) {
        final error = decoded['error'];
        if (error is Map && error['message'] != null) {
          detail = error['message'].toString();
        }
      }
      throw AiServiceException(
        detail == null || detail.isEmpty
            ? 'Provider request failed (${response.statusCode}). Check the key, model, and account limits.'
            : 'Provider request failed (${response.statusCode}): $detail',
      );
    }
    if (decoded is! Map<String, dynamic>) {
      throw const AiServiceException('The provider response was not JSON.');
    }
    return decoded;
  }

  String _safeError(Object error) {
    final text = error.toString();
    return text.length > 180 ? '${text.substring(0, 180)}…' : text;
  }
}

class AiServiceException implements Exception {
  const AiServiceException(this.message);

  final String message;

  @override
  String toString() => message;
}

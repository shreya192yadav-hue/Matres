import 'api_service.dart';
import 'local_preferences.dart';
import 'ocr_service.dart';
import 'overlay_service.dart';
import 'screen_capture_service.dart';
import 'speech_service.dart';

final appPreferences = LocalPreferences();
final aiService = AiService(appPreferences);
final captureService = ScreenCaptureService();
final overlayService = OverlayService();
final ocrService = OcrService();
final speechService = SpeechService();

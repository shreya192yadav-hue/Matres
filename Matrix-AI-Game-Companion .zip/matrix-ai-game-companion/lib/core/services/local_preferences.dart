import 'package:shared_preferences/shared_preferences.dart';

enum AiProvider {
  gemini('GEMINI', 'Gemini'),
  openRouter('OPENROUTER', 'OpenRouter');

  const AiProvider(this.storageKey, this.label);

  final String storageKey;
  final String label;
}

class LocalPreferences {
  static const _providerKey = 'connection.provider';
  static const _modelKey = 'connection.model';
  static const _linkedKey = 'connection.linked';
  static const _gamePackageKey = 'game.package';
  static const _featurePrefix = 'feature.';
  static const _apiKeyPrefix = 'api_key.';

  SharedPreferences? _preferences;

  Future<void> initialize() async {
    _preferences ??= await SharedPreferences.getInstance();
  }

  SharedPreferences get _store {
    final store = _preferences;
    if (store == null) {
      throw StateError('LocalPreferences.initialize() has not completed.');
    }
    return store;
  }

  AiProvider get provider {
    final value = _store.getString(_providerKey);
    return AiProvider.values.firstWhere(
      (item) => item.storageKey == value,
      orElse: () => AiProvider.gemini,
    );
  }

  String get model => _store.getString(_modelKey) ?? 'gemini-3.8-flash';

  bool get linked => _store.getBool(_linkedKey) ?? false;

  String get gamePackage => _store.getString(_gamePackageKey) ?? '';

  String apiKeyFor(AiProvider provider) =>
      _store.getString('$_apiKeyPrefix${provider.storageKey}') ?? '';

  bool featureEnabled(String feature) =>
      _store.getBool('$_featurePrefix$feature') ?? false;

  Future<void> saveConnection({
    required AiProvider provider,
    required String model,
    required String apiKey,
  }) async {
    await _store.setString(_providerKey, provider.storageKey);
    await _store.setString(_modelKey, model.trim());
    await _store.setString('$_apiKeyPrefix${provider.storageKey}', apiKey);
    await _store.setBool(_linkedKey, true);
  }

  Future<void> setLinked(bool value) async {
    await _store.setBool(_linkedKey, value);
  }

  Future<void> saveFeature(String feature, bool enabled) async {
    await _store.setBool('$_featurePrefix$feature', enabled);
  }

  Future<void> saveGamePackage(String packageName) async {
    await _store.setString(_gamePackageKey, packageName.trim());
  }
}

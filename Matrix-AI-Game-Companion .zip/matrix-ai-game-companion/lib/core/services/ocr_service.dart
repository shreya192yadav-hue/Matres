import 'dart:io';

import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:path_provider/path_provider.dart';

class OcrService {
  final TextRecognizer _recognizer = TextRecognizer(
    script: TextRecognitionScript.latin,
  );

  Future<String> readEnglishText(List<int> jpegBytes) async {
    final temporaryDirectory = await getTemporaryDirectory();
    final frame = File(
      '${temporaryDirectory.path}/matrix-frame-${DateTime.now().microsecondsSinceEpoch}.jpg',
    );
    try {
      await frame.writeAsBytes(jpegBytes, flush: true);
      final result = await _recognizer.processImage(
        InputImage.fromFilePath(frame.path),
      );
      return result.text.trim();
    } finally {
      if (await frame.exists()) await frame.delete();
    }
  }

  Future<void> dispose() => _recognizer.close();
}

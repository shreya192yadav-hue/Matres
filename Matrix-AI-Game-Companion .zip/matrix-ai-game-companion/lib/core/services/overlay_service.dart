import 'dart:async';
import 'dart:convert';

import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'package:flutter_screen_recording/flutter_screen_recording.dart';
import 'package:permission_handler/permission_handler.dart';

class OverlayService {
  StreamSubscription<dynamic>? _subscription;

  Future<void> listen(
    Future<void> Function(OverlayAction action) onAction,
  ) async {
    await _subscription?.cancel();
    _subscription = FlutterOverlayWindow.overlayListener.listen((event) {
      final action = OverlayAction.tryParse(event);
      if (action != null) unawaited(onAction(action));
    });
  }

  Future<bool> initializeOverlay() async {
    var permitted = await FlutterOverlayWindow.isPermissionGranted();
    if (!permitted) {
      permitted = await FlutterOverlayWindow.requestPermission() ?? false;
    }
    if (!permitted) return false;

    await FlutterOverlayWindow.showOverlay(
      height: 108,
      width: 240,
      alignment: OverlayAlignment.centerRight,
      enableDrag: true,
      overlayTitle: 'Matrix AI HUD',
      overlayContent:
          'Tap for voice • double-tap to translate • hold to record',
    );
    return true;
  }

  Future<void> close() async {
    await FlutterOverlayWindow.closeOverlay();
  }

  Future<void> sendGuidance(String message) => FlutterOverlayWindow.shareData(
    jsonEncode({'type': 'guidance', 'text': message}),
  );

  Future<bool> startRecording() async {
    final notificationStatus = await Permission.notification.status;
    if (notificationStatus.isDenied) {
      await Permission.notification.request();
    }
    return FlutterScreenRecording.startRecordScreen(
      'matrix_gameplay_${DateTime.now().millisecondsSinceEpoch}',
      titleNotification: 'Matrix AI Game Companion',
      messageNotification: 'Gameplay screen recording is active.',
    );
  }

  Future<String> stopRecording() => FlutterScreenRecording.stopRecordScreen;

  void dispose() {
    unawaited(_subscription?.cancel());
    _subscription = null;
  }
}

enum OverlayAction {
  voice,
  translate,
  record,
  close;

  static OverlayAction? tryParse(dynamic raw) {
    try {
      final data = raw is String ? jsonDecode(raw) : raw;
      if (data is! Map<String, dynamic>) return null;
      return switch (data['action']) {
        'voice' => OverlayAction.voice,
        'translate' => OverlayAction.translate,
        'record' => OverlayAction.record,
        'close' => OverlayAction.close,
        _ => null,
      };
    } on FormatException {
      return null;
    }
  }

  static String encode(OverlayAction action) =>
      jsonEncode({'action': action.name});
}

import 'dart:typed_data';

import 'package:flutter/services.dart';

class ScreenCaptureService {
  static const _channel = MethodChannel('com.matrix.companion/screen_capture');
  bool _active = false;
  Future<bool>? _pendingStart;

  Future<bool> start() async {
    if (_active) return true;
    if (_pendingStart != null) return _pendingStart!;
    final request = _requestStart();
    _pendingStart = request;
    try {
      return await request;
    } finally {
      _pendingStart = null;
    }
  }

  Future<bool> _requestStart() async {
    try {
      _active = await _channel.invokeMethod<bool>('startCapture') ?? false;
      return _active;
    } on PlatformException catch (error) {
      throw ScreenCaptureException(error.message ?? 'Screen capture failed.');
    } on MissingPluginException {
      throw const ScreenCaptureException(
        'Screen capture is available in the Android app only.',
      );
    }
  }

  Future<Uint8List?> latestFrame() async {
    try {
      final frame = await _channel.invokeMethod<Uint8List>('latestFrame');
      if (frame == null && _active) {
        _active = false;
        throw const ScreenCaptureException(
          'Screen access ended. Disable and re-enable a screen module to reconnect.',
        );
      }
      return frame;
    } on ScreenCaptureException {
      rethrow;
    } on PlatformException catch (error) {
      throw ScreenCaptureException(
        error.message ?? 'Could not read the frame.',
      );
    }
  }

  Future<void> stop() async {
    _active = false;
    try {
      await _channel.invokeMethod<void>('stopCapture');
    } on MissingPluginException {
      // The Android-only channel is not registered on other platforms.
    } on PlatformException {
      // Capture may already have been stopped by Android or the user.
    }
  }
}

class ScreenCaptureException implements Exception {
  const ScreenCaptureException(this.message);

  final String message;

  @override
  String toString() => message;
}

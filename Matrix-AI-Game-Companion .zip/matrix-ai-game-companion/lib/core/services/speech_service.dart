import 'package:flutter_tts/flutter_tts.dart';

class SpeechService {
  final FlutterTts _tts = FlutterTts();
  bool _initialized = false;

  Future<void> initialize() async {
    if (_initialized) return;
    await _tts.setSpeechRate(0.48);
    await _tts.setVolume(0.9);
    await _tts.setPitch(1.0);
    _initialized = true;
  }

  Future<void> speak(String text, {String language = 'en-US'}) async {
    final message = text.trim();
    if (message.isEmpty) return;
    await initialize();
    await _tts.stop();
    await _tts.setLanguage(language);
    await _tts.speak(message);
  }

  Future<void> stop() async {
    await _tts.stop();
  }
}

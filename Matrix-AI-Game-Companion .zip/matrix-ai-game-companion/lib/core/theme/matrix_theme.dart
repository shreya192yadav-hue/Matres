import 'package:flutter/material.dart';

abstract final class MatrixColors {
  static const background = Color(0xFF030A05);
  static const surface = Color(0xFF08140C);
  static const raised = Color(0xFF0B1C11);
  static const neon = Color(0xFF00FF66);
  static const mint = Color(0xFF8CFFB5);
  static const text = Color(0xFFE3F5E8);
  static const muted = Color(0xFF7A9682);
  static const border = Color(0xFF173822);
  static const danger = Color(0xFFFF5D68);
  static const amber = Color(0xFFFFC857);
}

abstract final class MatrixTheme {
  static ThemeData get dark => ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: MatrixColors.background,
    colorScheme: const ColorScheme.dark(
      primary: MatrixColors.neon,
      secondary: MatrixColors.mint,
      surface: MatrixColors.surface,
      error: MatrixColors.danger,
    ),
    fontFamily: 'monospace',
    textTheme: const TextTheme(
      headlineLarge: TextStyle(
        color: MatrixColors.text,
        fontSize: 28,
        fontWeight: FontWeight.w800,
        letterSpacing: -1.2,
      ),
      headlineSmall: TextStyle(
        color: MatrixColors.text,
        fontSize: 18,
        fontWeight: FontWeight.w700,
      ),
      bodyLarge: TextStyle(color: MatrixColors.text, fontSize: 14),
      bodyMedium: TextStyle(color: MatrixColors.muted, fontSize: 12),
      labelLarge: TextStyle(
        color: MatrixColors.background,
        fontWeight: FontWeight.w800,
        letterSpacing: 1.1,
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: MatrixColors.background,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      hintStyle: const TextStyle(color: MatrixColors.muted, fontSize: 12),
      labelStyle: const TextStyle(color: MatrixColors.muted, fontSize: 12),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: MatrixColors.border),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: MatrixColors.neon, width: 1.3),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: MatrixColors.danger),
      ),
    ),
    switchTheme: SwitchThemeData(
      thumbColor: WidgetStateProperty.resolveWith(
        (states) => states.contains(WidgetState.selected)
            ? MatrixColors.neon
            : MatrixColors.muted,
      ),
      trackColor: WidgetStateProperty.resolveWith(
        (states) => states.contains(WidgetState.selected)
            ? MatrixColors.neon.withValues(alpha: 0.25)
            : MatrixColors.raised,
      ),
      trackOutlineColor: WidgetStateProperty.all(MatrixColors.border),
    ),
    snackBarTheme: const SnackBarThemeData(
      backgroundColor: MatrixColors.raised,
      contentTextStyle: TextStyle(color: MatrixColors.text),
    ),
  );
}

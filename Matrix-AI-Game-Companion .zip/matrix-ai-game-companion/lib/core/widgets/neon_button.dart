import 'package:flutter/material.dart';

import '../theme/matrix_theme.dart';

class NeonButton extends StatefulWidget {
  const NeonButton({
    required this.label,
    required this.onPressed,
    this.icon,
    this.busy = false,
    this.compact = false,
    super.key,
  });

  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final bool busy;
  final bool compact;

  @override
  State<NeonButton> createState() => _NeonButtonState();
}

class _NeonButtonState extends State<NeonButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulse = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1800),
    lowerBound: 0.15,
    upperBound: 0.55,
  )..repeat(reverse: true);

  @override
  void dispose() {
    _pulse.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final enabled = widget.onPressed != null && !widget.busy;
    return AnimatedBuilder(
      animation: _pulse,
      builder: (context, child) => DecoratedBox(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(13),
          boxShadow: enabled
              ? [
                  BoxShadow(
                    color: MatrixColors.neon.withValues(alpha: _pulse.value),
                    blurRadius: 18,
                    spreadRadius: 0.2,
                  ),
                ]
              : const [],
        ),
        child: child,
      ),
      child: Material(
        color: enabled ? MatrixColors.neon : MatrixColors.raised,
        borderRadius: BorderRadius.circular(13),
        child: InkWell(
          onTap: enabled ? widget.onPressed : null,
          borderRadius: BorderRadius.circular(13),
          splashColor: MatrixColors.background.withValues(alpha: 0.15),
          child: Padding(
            padding: EdgeInsets.symmetric(
              horizontal: widget.compact ? 15 : 18,
              vertical: widget.compact ? 13 : 16,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: widget.compact
                  ? MainAxisSize.min
                  : MainAxisSize.max,
              children: [
                if (widget.busy)
                  const SizedBox(
                    width: 15,
                    height: 15,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: MatrixColors.neon,
                    ),
                  )
                else if (widget.icon != null)
                  Icon(
                    widget.icon,
                    size: 16,
                    color: enabled
                        ? MatrixColors.background
                        : MatrixColors.muted,
                  ),
                if (widget.icon != null || widget.busy)
                  const SizedBox(width: 9),
                Flexible(
                  child: Text(
                    widget.label,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: enabled
                          ? MatrixColors.background
                          : MatrixColors.muted,
                      fontFamily: 'monospace',
                      fontSize: widget.compact ? 10 : 11,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.7,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

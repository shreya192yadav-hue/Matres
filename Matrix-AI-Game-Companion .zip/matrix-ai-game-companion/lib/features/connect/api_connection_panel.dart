import 'package:flutter/material.dart';

import '../../core/services/local_preferences.dart';
import '../../core/theme/matrix_theme.dart';
import '../../core/widgets/neon_button.dart';

class ApiConnectionPanel extends StatefulWidget {
  const ApiConnectionPanel({
    required this.provider,
    required this.model,
    required this.initialKey,
    required this.linked,
    required this.busy,
    required this.statusMessage,
    required this.onProviderChanged,
    required this.onModelChanged,
    required this.onConnect,
    super.key,
  });

  final AiProvider provider;
  final String model;
  final String initialKey;
  final bool linked;
  final bool busy;
  final String statusMessage;
  final ValueChanged<AiProvider> onProviderChanged;
  final ValueChanged<String> onModelChanged;
  final Future<void> Function(String key) onConnect;

  @override
  State<ApiConnectionPanel> createState() => _ApiConnectionPanelState();
}

class _ApiConnectionPanelState extends State<ApiConnectionPanel> {
  late final TextEditingController _keyController = TextEditingController(
    text: widget.initialKey,
  );
  late final TextEditingController _modelController = TextEditingController(
    text: widget.model,
  );
  bool _showKey = false;

  @override
  void didUpdateWidget(covariant ApiConnectionPanel oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.initialKey != widget.initialKey &&
        _keyController.text != widget.initialKey) {
      _keyController.text = widget.initialKey;
    }
    if (oldWidget.model != widget.model &&
        _modelController.text != widget.model) {
      _modelController.text = widget.model;
    }
  }

  @override
  void dispose() {
    _keyController.dispose();
    _modelController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final activeColor = widget.linked ? MatrixColors.neon : MatrixColors.muted;
    return Container(
      padding: const EdgeInsets.all(17),
      decoration: BoxDecoration(
        color: MatrixColors.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: widget.linked
              ? MatrixColors.neon.withValues(alpha: 0.58)
              : MatrixColors.border,
        ),
        boxShadow: widget.linked
            ? [
                BoxShadow(
                  color: MatrixColors.neon.withValues(alpha: 0.08),
                  blurRadius: 20,
                ),
              ]
            : const [],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.terminal, color: MatrixColors.neon, size: 18),
              const SizedBox(width: 9),
              const Expanded(
                child: Text(
                  'API TERMINAL',
                  style: TextStyle(
                    color: MatrixColors.text,
                    fontWeight: FontWeight.w800,
                    fontSize: 12,
                    letterSpacing: 1.2,
                  ),
                ),
              ),
              Icon(Icons.circle, size: 9, color: activeColor),
              const SizedBox(width: 7),
              Text(
                widget.linked ? 'LINKED & ACTIVE' : 'NOT LINKED',
                style: TextStyle(
                  color: activeColor,
                  fontSize: 9,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.65,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          DropdownButtonFormField<AiProvider>(
            initialValue: widget.provider,
            decoration: const InputDecoration(labelText: 'AI PROVIDER'),
            dropdownColor: MatrixColors.raised,
            items: AiProvider.values
                .map(
                  (provider) => DropdownMenuItem(
                    value: provider,
                    child: Text(
                      provider.label,
                      style: const TextStyle(
                        color: MatrixColors.text,
                        fontSize: 12,
                      ),
                    ),
                  ),
                )
                .toList(),
            onChanged: widget.busy
                ? null
                : (provider) {
                    if (provider != null) widget.onProviderChanged(provider);
                  },
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _modelController,
            enabled: !widget.busy,
            autocorrect: false,
            onChanged: widget.onModelChanged,
            decoration: const InputDecoration(
              labelText: 'MODEL ID',
              hintText: 'gemini-3.8-flash',
            ),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _keyController,
            enabled: !widget.busy,
            obscureText: !_showKey,
            autocorrect: false,
            enableSuggestions: false,
            keyboardType: TextInputType.visiblePassword,
            decoration: InputDecoration(
              labelText: 'API KEY',
              hintText: widget.provider == AiProvider.gemini
                  ? 'Paste your Gemini API key'
                  : 'Paste your OpenRouter API key',
              suffixIcon: IconButton(
                onPressed: () => setState(() => _showKey = !_showKey),
                tooltip: _showKey ? 'Hide API key' : 'Show API key',
                icon: Icon(
                  _showKey ? Icons.visibility_off : Icons.visibility,
                  color: MatrixColors.muted,
                  size: 19,
                ),
              ),
            ),
          ),
          const SizedBox(height: 14),
          NeonButton(
            label: 'EXECUTE CONNECT & SAVE',
            icon: Icons.bolt,
            busy: widget.busy,
            onPressed: widget.busy
                ? null
                : () => widget.onConnect(_keyController.text.trim()),
          ),
          if (widget.statusMessage.isNotEmpty) ...[
            const SizedBox(height: 11),
            Text(
              widget.statusMessage,
              style: TextStyle(
                color: widget.linked ? MatrixColors.mint : MatrixColors.amber,
                fontSize: 10,
                height: 1.45,
              ),
            ),
          ],
          const SizedBox(height: 10),
          const Text(
            'KEY STAYS ON THIS DEVICE • MODEL IDS ARE PROVIDER-DEPENDENT',
            style: TextStyle(
              color: MatrixColors.muted,
              fontSize: 8,
              height: 1.45,
              letterSpacing: 0.25,
            ),
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';

import '../../core/theme/matrix_theme.dart';

class DashboardGrid extends StatelessWidget {
  const DashboardGrid({
    required this.enabled,
    required this.onChanged,
    super.key,
  });

  final Map<String, bool> enabled;
  final Future<void> Function(String id, bool value) onChanged;

  static const modules = <DashboardModule>[
    DashboardModule(
      id: 'recorder',
      icon: Icons.fiber_manual_record,
      title: 'AUTO SCREEN RECORDER',
      description:
          'Capture gameplay to an MP4 file with Android screen consent.',
      color: MatrixColors.danger,
      tag: 'MP4',
    ),
    DashboardModule(
      id: 'vision',
      icon: Icons.remove_red_eye_outlined,
      title: 'VISION HUD ANALYZER',
      description: 'Read game frames and request live tactical commentary.',
      color: MatrixColors.neon,
      tag: 'LIVE AI',
    ),
    DashboardModule(
      id: 'translator',
      icon: Icons.translate,
      title: 'OCR & TEXT TRANSLATOR',
      description: 'Extract English game text and translate it into Hindi.',
      color: Color(0xFF4BD9FF),
      tag: 'EN → HI',
    ),
    DashboardModule(
      id: 'companion',
      icon: Icons.graphic_eq,
      title: 'AI MIND & VOICE',
      description: 'Ask the companion for tactics and spoken game guidance.',
      color: Color(0xFFFFC857),
      tag: 'VOICE',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final columns = constraints.maxWidth > 620 ? 4 : 2;
        final ratio = columns == 2 ? 0.92 : 0.88;
        return GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: modules.length,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: columns,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: ratio,
          ),
          itemBuilder: (context, index) {
            final module = modules[index];
            final isEnabled = enabled[module.id] ?? false;
            return _ModuleCard(
              module: module,
              enabled: isEnabled,
              onChanged: (value) => onChanged(module.id, value),
            );
          },
        );
      },
    );
  }
}

class DashboardModule {
  const DashboardModule({
    required this.id,
    required this.icon,
    required this.title,
    required this.description,
    required this.color,
    required this.tag,
  });

  final String id;
  final IconData icon;
  final String title;
  final String description;
  final Color color;
  final String tag;
}

class _ModuleCard extends StatelessWidget {
  const _ModuleCard({
    required this.module,
    required this.enabled,
    required this.onChanged,
  });

  final DashboardModule module;
  final bool enabled;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    final accent = enabled ? module.color : MatrixColors.muted;
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: MatrixColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: enabled
              ? module.color.withValues(alpha: 0.52)
              : MatrixColors.border,
        ),
        boxShadow: enabled
            ? [
                BoxShadow(
                  color: module.color.withValues(alpha: 0.07),
                  blurRadius: 16,
                ),
              ]
            : const [],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(module.icon, size: 18, color: accent),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
                decoration: BoxDecoration(
                  color: accent.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(5),
                ),
                child: Text(
                  module.tag,
                  style: TextStyle(
                    color: accent,
                    fontSize: 7,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 0.4,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            module.title,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: MatrixColors.text,
              fontWeight: FontWeight.w800,
              fontSize: 9,
              height: 1.4,
              letterSpacing: 0.35,
            ),
          ),
          const SizedBox(height: 7),
          Expanded(
            child: Text(
              module.description,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: MatrixColors.muted,
                fontSize: 9,
                height: 1.45,
              ),
            ),
          ),
          Row(
            children: [
              Text(
                enabled ? 'ACTIVE' : 'STANDBY',
                style: TextStyle(
                  color: accent,
                  fontSize: 8,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.6,
                ),
              ),
              const Spacer(),
              SizedBox(
                height: 28,
                child: Switch(
                  value: enabled,
                  onChanged: onChanged,
                  materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

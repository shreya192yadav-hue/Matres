import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../core/services/api_service.dart';
import '../../core/services/local_preferences.dart';
import '../../core/services/overlay_service.dart';
import '../../core/services/screen_capture_service.dart';
import '../../core/theme/matrix_theme.dart';
import '../../core/widgets/neon_button.dart';
import '../../core/services/app_services.dart' as services;
import '../connect/api_connection_panel.dart';
import '../../ui/dashboard_grid.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final _gamePackageController = TextEditingController();
  final _questionController = TextEditingController();
  final Map<String, bool> _features = {
    'recorder': false,
    'vision': false,
    'translator': false,
    'companion': false,
  };

  AiProvider _provider = AiProvider.gemini;
  String _model = 'gemini-3.8-flash';
  String _currentInsight =
      'Awaiting a live link. Connect a provider to start game analysis.';
  String _connectionMessage = '';
  String _recordingPath = '';
  bool _linked = false;
  bool _ready = false;
  bool _connecting = false;
  bool _recording = false;
  bool _overlayActive = false;
  bool _busy = false;
  Timer? _frameTimer;

  bool get _needsScreenCapture =>
      (_features['vision'] ?? false) || (_features['translator'] ?? false);

  @override
  void initState() {
    super.initState();
    unawaited(_loadSettings());
    unawaited(services.overlayService.listen(_handleOverlayAction));
  }

  Future<void> _loadSettings() async {
    final preferences = services.appPreferences;
    _provider = preferences.provider;
    _model = preferences.model;
    _linked = preferences.linked;
    _gamePackageController.text = preferences.gamePackage;
    for (final id in _features.keys) {
      _features[id] = preferences.featureEnabled(id);
    }
    if (!mounted) return;
    setState(() => _ready = true);
    if (_needsScreenCapture && _linked) {
      try {
        final started = await services.captureService.start();
        if (!started) {
          _features['vision'] = false;
          _features['translator'] = false;
          await services.appPreferences.saveFeature('vision', false);
          await services.appPreferences.saveFeature('translator', false);
          if (mounted) setState(() {});
        }
      } catch (error) {
        _showStatus('Screen capture could not resume: $error');
      }
    }
    _updateFrameTimer();
  }

  @override
  void dispose() {
    _frameTimer?.cancel();
    _gamePackageController.dispose();
    _questionController.dispose();
    services.overlayService.dispose();
    services.ocrService.dispose();
    services.speechService.stop();
    services.captureService.stop();
    super.dispose();
  }

  void _showStatus(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _saveConnection(String apiKey) async {
    final key = apiKey.trim();
    if (key.isEmpty) {
      _showStatus('Enter an API key first.');
      return;
    }
    if (_model.trim().isEmpty) {
      _showStatus('Enter a model ID first.');
      return;
    }
    setState(() {
      _connecting = true;
      _connectionMessage = 'Checking provider credentials…';
    });
    try {
      await services.aiService.testConnection(
        provider: _provider,
        apiKey: key,
        model: _model,
      );
      await services.appPreferences.saveConnection(
        provider: _provider,
        model: _model,
        apiKey: key,
      );
      if (!mounted) return;
      setState(() {
        _linked = true;
        _connectionMessage =
            'Provider responded. API key saved on this device.';
      });
      if (_needsScreenCapture) {
        try {
          await services.captureService.start();
        } catch (error) {
          _showStatus(
            'AI connection is active, but screen capture could not start: $error',
          );
        }
      }
    } on AiServiceException catch (error) {
      if (!mounted) return;
      setState(() {
        _linked = false;
        _connectionMessage = error.message;
      });
      await services.appPreferences.setLinked(false);
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _linked = false;
        _connectionMessage = 'Connection failed: $error';
      });
      await services.appPreferences.setLinked(false);
    } finally {
      if (mounted) {
        setState(() => _connecting = false);
        _updateFrameTimer();
      }
    }
  }

  Future<void> _changeProvider(AiProvider provider) async {
    setState(() {
      _provider = provider;
      _model = provider == AiProvider.gemini
          ? 'gemini-3.8-flash'
          : 'google/gemini-3.8-flash';
      _linked = false;
      _connectionMessage = '';
    });
    await services.appPreferences.setLinked(false);
    _updateFrameTimer();
  }

  Future<void> _toggleFeature(String id, bool enabled) async {
    if (id != 'recorder' && id != 'companion' && enabled && !_linked) {
      _showStatus('Connect Gemini or OpenRouter before enabling this module.');
      return;
    }
    if ((id == 'vision' || id == 'translator') && enabled) {
      try {
        final permitted = await services.captureService.start();
        if (!permitted) {
          _showStatus('Screen capture permission was not granted.');
          return;
        }
      } catch (error) {
        _showStatus('Screen capture setup failed: $error');
        return;
      }
    }
    if (id == 'recorder' && !enabled && _recording) {
      try {
        final path = await services.overlayService.stopRecording();
        if (mounted) {
          setState(() {
            _recording = false;
            _recordingPath = path;
          });
        }
      } catch (error) {
        _showStatus(
          'Stop the active recording before disabling the module: $error',
        );
        return;
      }
    }
    if (id == 'companion' && !enabled) {
      await services.speechService.stop();
    }

    setState(() => _features[id] = enabled);
    await services.appPreferences.saveFeature(id, enabled);
    if (!_needsScreenCapture) await services.captureService.stop();
    _updateFrameTimer();
  }

  void _updateFrameTimer() {
    _frameTimer?.cancel();
    if (_needsScreenCapture && _linked && _ready) {
      _frameTimer = Timer.periodic(
        const Duration(seconds: 8),
        (_) => _processLiveFrame(),
      );
    }
  }

  Future<void> _processLiveFrame() async {
    if (_busy || !_needsScreenCapture || !_linked) return;
    _busy = true;
    try {
      final frame = await services.captureService.latestFrame();
      if (frame == null || frame.isEmpty) return;
      final updates = <String>[];
      if (_features['vision'] ?? false) {
        final commentary = await services.aiService.analyzeFrame(
          jpegBytes: frame,
          instruction:
              'You are a concise game coach. Describe the visible game state, '
              'the most useful next action, and one immediate risk in 2 or 3 '
              'short sentences. Do not invent details that are not visible.',
        );
        updates.add('VISION • $commentary');
      }
      if (_features['translator'] ?? false) {
        final text = await services.ocrService.readEnglishText(frame);
        if (text.isNotEmpty) {
          final hindi = await services.aiService.translateToHindi(text);
          if (hindi.isNotEmpty) updates.add('EN → HI • $hindi');
        }
      }
      if (updates.isNotEmpty && mounted) {
        final result = updates.join('\n\n');
        setState(() => _currentInsight = result);
        await services.overlayService.sendGuidance(result);
      }
    } on AiServiceException catch (error) {
      if (mounted)
        setState(() => _currentInsight = 'AI ERROR • ${error.message}');
    } catch (error) {
      if (mounted) setState(() => _currentInsight = 'CAPTURE ERROR • $error');
    } finally {
      _busy = false;
    }
  }

  Future<void> _handleOverlayAction(OverlayAction action) async {
    switch (action) {
      case OverlayAction.voice:
        await _voiceGuide();
      case OverlayAction.translate:
        await _translateCurrentFrame();
      case OverlayAction.record:
        await _toggleRecording();
      case OverlayAction.close:
        await services.overlayService.close();
    }
  }

  Future<void> _voiceGuide() async {
    if (!(_features['companion'] ?? false)) {
      _showStatus('Enable AI Mind & Voice before using the HUD voice action.');
      return;
    }
    if (_busy) return;
    setState(() => _busy = true);
    try {
      final frame = _needsScreenCapture
          ? await services.captureService.latestFrame()
          : null;
      final guidance = frame == null
          ? await services.aiService.ask(
              'Give one concise, general gaming focus tip. Be clear and useful.',
            )
          : await services.aiService.analyzeFrame(
              jpegBytes: frame,
              instruction:
                  'Give one concise spoken game instruction based only on '
                  'what is visible. Keep it under 35 words.',
            );
      if (!mounted) return;
      setState(() => _currentInsight = guidance);
      await services.overlayService.sendGuidance(guidance);
      await services.speechService.speak(guidance);
    } catch (error) {
      _showStatus('Voice guide failed: $error');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _translateCurrentFrame() async {
    if (_busy) return;
    if (!(_features['translator'] ?? false)) {
      _showStatus('Enable OCR & Text Translator before using this HUD action.');
      return;
    }
    if (!_linked) {
      _showStatus('Connect an AI provider before translating screen text.');
      return;
    }
    setState(() => _busy = true);
    try {
      final frame = await services.captureService.latestFrame();
      if (frame == null) {
        throw const ScreenCaptureException(
          'Turn on the OCR module and grant screen capture first.',
        );
      }
      final sourceText = await services.ocrService.readEnglishText(frame);
      if (sourceText.isEmpty) {
        throw const AiServiceException(
          'No English text was found in this frame.',
        );
      }
      final translation = await services.aiService.translateToHindi(sourceText);
      if (!mounted) return;
      setState(() => _currentInsight = 'EN → HI • $translation');
      await services.overlayService.sendGuidance(translation);
      await services.speechService.speak(translation, language: 'hi-IN');
    } catch (error) {
      _showStatus('Translation failed: $error');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _toggleRecording() async {
    if (!(_features['recorder'] ?? false)) {
      _showStatus('Enable Auto Screen Recorder before starting a recording.');
      return;
    }
    if (_recording) {
      try {
        final path = await services.overlayService.stopRecording();
        if (!mounted) return;
        setState(() {
          _recording = false;
          _recordingPath = path;
        });
        _showStatus('Recording saved: $path');
      } catch (error) {
        _showStatus('Could not stop the recording: $error');
      }
      return;
    }
    try {
      final started = await services.overlayService.startRecording();
      if (!mounted) return;
      if (started) {
        setState(() {
          _recording = true;
          _recordingPath = '';
        });
        _showStatus('Recording started. Long-press the HUD to stop it.');
      } else {
        _showStatus('Recording permission was not granted.');
      }
    } catch (error) {
      _showStatus('Could not start screen recording: $error');
    }
  }

  Future<void> _initializeOverlay() async {
    final packageName = _gamePackageController.text.trim();
    await services.appPreferences.saveGamePackage(packageName);
    try {
      final enabled = await services.overlayService.initializeOverlay();
      if (!enabled) {
        _showStatus('Allow display-over-other-apps permission to continue.');
        return;
      }
      if (mounted) setState(() => _overlayActive = true);
      if (packageName.isEmpty) {
        _showStatus('HUD is ready. Add a game package name to launch a game.');
        return;
      }
      final launched = await const MethodChannel(
        'com.matrix.companion/screen_capture',
      ).invokeMethod<bool>('launchGame', {'packageName': packageName});
      if (launched != true) {
        _showStatus(
          'HUD is ready, but Android could not open "$packageName". Check the package name.',
        );
      } else {
        _showStatus('HUD initialized. Game launch requested.');
      }
    } on PlatformException catch (error) {
      _showStatus(error.message ?? 'Could not initialize the overlay.');
    } on MissingPluginException {
      _showStatus('Game launch and overlay are available on Android only.');
    } catch (error) {
      _showStatus('Overlay setup failed: $error');
    }
  }

  Future<void> _closeOverlay() async {
    try {
      await services.overlayService.close();
      if (mounted) setState(() => _overlayActive = false);
      _showStatus('Floating HUD closed.');
    } catch (error) {
      _showStatus('Could not close the floating HUD: $error');
    }
  }

  Future<void> _askCompanion() async {
    if (_busy) return;
    if (!(_features['companion'] ?? false)) {
      _showStatus('Enable AI Mind & Voice to ask a game question.');
      return;
    }
    if (!_linked) {
      _showStatus('Connect an AI provider before asking for game guidance.');
      return;
    }
    final question = _questionController.text.trim();
    if (question.isEmpty) {
      _showStatus('Type a question for the companion first.');
      return;
    }
    setState(() => _busy = true);
    try {
      final answer = await services.aiService.ask(
        'You are the Matrix AI game companion. Give practical, concise player '
        'guidance and audience-friendly commentary. User asks: $question',
      );
      if (!mounted) return;
      setState(() => _currentInsight = answer);
      await services.overlayService.sendGuidance(answer);
      await services.speechService.speak(answer);
      _questionController.clear();
    } catch (error) {
      _showStatus('Companion request failed: $error');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final providerKey = services.appPreferences.apiKeyFor(_provider);
    return Scaffold(
      bottomNavigationBar: SafeArea(
        top: false,
        child: Container(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
          decoration: const BoxDecoration(
            color: MatrixColors.background,
            border: Border(top: BorderSide(color: MatrixColors.border)),
          ),
          child: Row(
            children: [
              Expanded(
                child: NeonButton(
                  label: 'INITIALIZE OVERLAY & LAUNCH GAME',
                  icon: Icons.open_in_new,
                  onPressed: _ready ? _initializeOverlay : null,
                ),
              ),
              const SizedBox(width: 8),
              Tooltip(
                message: _recording
                    ? 'Stop screen recording'
                    : 'Start screen recording',
                child: Material(
                  color: _recording ? MatrixColors.danger : MatrixColors.raised,
                  borderRadius: BorderRadius.circular(13),
                  child: InkWell(
                    onTap: _toggleRecording,
                    borderRadius: BorderRadius.circular(13),
                    child: SizedBox(
                      width: 48,
                      height: 48,
                      child: Icon(
                        _recording ? Icons.stop : Icons.fiber_manual_record,
                        color: _recording ? Colors.white : MatrixColors.danger,
                        size: 18,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      body: SafeArea(
        child: _ready
            ? SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 24),
                child: Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 820),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildHeader(),
                        const SizedBox(height: 18),
                        ApiConnectionPanel(
                          provider: _provider,
                          model: _model,
                          initialKey: providerKey,
                          linked: _linked,
                          busy: _connecting,
                          statusMessage: _connectionMessage,
                          onProviderChanged: _changeProvider,
                          onModelChanged: (value) => _model = value,
                          onConnect: _saveConnection,
                        ),
                        const SizedBox(height: 22),
                        _sectionHeading('CAPABILITY MATRIX', '04 MODULES'),
                        const SizedBox(height: 11),
                        DashboardGrid(
                          enabled: _features,
                          onChanged: _toggleFeature,
                        ),
                        const SizedBox(height: 19),
                        _buildGameTarget(),
                        const SizedBox(height: 15),
                        _buildCompanionPrompt(),
                        const SizedBox(height: 15),
                        _buildInsight(),
                        const SizedBox(height: 16),
                        const _GestureLegend(),
                        const SizedBox(height: 9),
                      ],
                    ),
                  ),
                ),
              )
            : const Center(
                child: CircularProgressIndicator(color: MatrixColors.neon),
              ),
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        Container(
          width: 43,
          height: 43,
          decoration: BoxDecoration(
            color: MatrixColors.neon.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: MatrixColors.neon.withValues(alpha: 0.55),
            ),
            boxShadow: [
              BoxShadow(
                color: MatrixColors.neon.withValues(alpha: 0.13),
                blurRadius: 16,
              ),
            ],
          ),
          child: const Icon(Icons.memory, color: MatrixColors.neon, size: 23),
        ),
        const SizedBox(width: 12),
        const Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'MATRIX AI',
                style: TextStyle(
                  color: MatrixColors.neon,
                  fontSize: 9,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 2,
                ),
              ),
              SizedBox(height: 3),
              Text(
                'GAME COMPANION',
                style: TextStyle(
                  color: MatrixColors.text,
                  fontSize: 15,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.2,
                ),
              ),
            ],
          ),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 7),
          decoration: BoxDecoration(
            color: (_linked ? MatrixColors.neon : MatrixColors.muted)
                .withValues(alpha: 0.08),
            border: Border.all(
              color: (_linked ? MatrixColors.neon : MatrixColors.border)
                  .withValues(alpha: 0.5),
            ),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Row(
            children: [
              Icon(
                Icons.circle,
                size: 7,
                color: _linked ? MatrixColors.neon : MatrixColors.muted,
              ),
              const SizedBox(width: 6),
              Text(
                _linked ? 'LINKED' : 'OFFLINE',
                style: TextStyle(
                  color: _linked ? MatrixColors.neon : MatrixColors.muted,
                  fontSize: 8,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _sectionHeading(String title, String trailing) => Row(
    children: [
      Text(
        title,
        style: const TextStyle(
          color: MatrixColors.text,
          fontSize: 11,
          fontWeight: FontWeight.w800,
          letterSpacing: 0.9,
        ),
      ),
      const Spacer(),
      Text(
        trailing,
        style: const TextStyle(
          color: MatrixColors.muted,
          fontSize: 8,
          letterSpacing: 0.8,
        ),
      ),
    ],
  );

  Widget _buildGameTarget() => Container(
    padding: const EdgeInsets.all(15),
    decoration: BoxDecoration(
      color: MatrixColors.surface,
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: MatrixColors.border),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Row(
          children: [
            Icon(Icons.sports_esports, color: MatrixColors.neon, size: 17),
            SizedBox(width: 8),
            Text(
              'GAME TARGET',
              style: TextStyle(
                color: MatrixColors.text,
                fontSize: 10,
                fontWeight: FontWeight.w800,
                letterSpacing: 0.8,
              ),
            ),
          ],
        ),
        const SizedBox(height: 11),
        TextField(
          controller: _gamePackageController,
          autocorrect: false,
          decoration: const InputDecoration(
            labelText: 'ANDROID PACKAGE NAME',
            hintText: 'com.example.game',
            prefixIcon: Icon(Icons.android, color: MatrixColors.muted),
          ),
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            const Expanded(
              child: Text(
                'Android shows a separate consent prompt for screen capture.',
                style: TextStyle(
                  color: MatrixColors.muted,
                  fontSize: 8,
                  height: 1.4,
                ),
              ),
            ),
            TextButton.icon(
              onPressed: _overlayActive ? _closeOverlay : null,
              icon: const Icon(Icons.close, size: 13),
              label: const Text('CLOSE HUD'),
              style: TextButton.styleFrom(
                foregroundColor: MatrixColors.muted,
                textStyle: const TextStyle(
                  fontFamily: 'monospace',
                  fontSize: 8,
                ),
              ),
            ),
          ],
        ),
      ],
    ),
  );

  Widget _buildInsight() => Container(
    width: double.infinity,
    padding: const EdgeInsets.all(15),
    decoration: BoxDecoration(
      color: MatrixColors.surface,
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: MatrixColors.border),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Icon(Icons.radar, color: MatrixColors.neon, size: 16),
            const SizedBox(width: 8),
            const Expanded(
              child: Text(
                'LIVE INTELLIGENCE',
                style: TextStyle(
                  color: MatrixColors.text,
                  fontSize: 9,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 0.8,
                ),
              ),
            ),
            if (_busy)
              const SizedBox(
                width: 12,
                height: 12,
                child: CircularProgressIndicator(
                  strokeWidth: 1.5,
                  color: MatrixColors.neon,
                ),
              ),
          ],
        ),
        const SizedBox(height: 11),
        Text(
          _currentInsight,
          style: const TextStyle(
            color: MatrixColors.mint,
            fontSize: 10,
            height: 1.55,
          ),
        ),
        if (_recordingPath.isNotEmpty) ...[
          const SizedBox(height: 9),
          Text(
            'LAST RECORDING • $_recordingPath',
            style: const TextStyle(
              color: MatrixColors.muted,
              fontSize: 8,
              height: 1.4,
            ),
          ),
        ],
        const SizedBox(height: 9),
        const Text(
          'Live analysis sends a frame to your chosen AI provider every 8 seconds while enabled. Provider usage or charges may apply.',
          style: TextStyle(color: MatrixColors.muted, fontSize: 8, height: 1.4),
        ),
      ],
    ),
  );

  Widget _buildCompanionPrompt() => Container(
    padding: const EdgeInsets.all(15),
    decoration: BoxDecoration(
      color: MatrixColors.surface,
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: MatrixColors.border),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Row(
          children: [
            Icon(Icons.forum_outlined, color: MatrixColors.neon, size: 16),
            SizedBox(width: 8),
            Text(
              'ASK THE COMPANION',
              style: TextStyle(
                color: MatrixColors.text,
                fontSize: 9,
                fontWeight: FontWeight.w800,
                letterSpacing: 0.8,
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        TextField(
          controller: _questionController,
          minLines: 1,
          maxLines: 3,
          textInputAction: TextInputAction.send,
          onSubmitted: (_) => _askCompanion(),
          decoration: const InputDecoration(
            hintText: 'Ask for a tactic, route, or quick commentary…',
          ),
        ),
        const SizedBox(height: 9),
        NeonButton(
          label: 'ASK & SPEAK',
          icon: Icons.graphic_eq,
          compact: true,
          busy: _busy,
          onPressed: _busy ? null : _askCompanion,
        ),
      ],
    ),
  );
}

class _GestureLegend extends StatelessWidget {
  const _GestureLegend();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: MatrixColors.raised.withValues(alpha: 0.7),
        borderRadius: BorderRadius.circular(13),
        border: Border.all(color: MatrixColors.border),
      ),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'FLOATING HUD CONTROLS',
            style: TextStyle(
              color: MatrixColors.neon,
              fontSize: 8,
              fontWeight: FontWeight.w800,
              letterSpacing: 0.8,
            ),
          ),
          SizedBox(height: 8),
          Text(
            'TAP  AI voice guidance     DOUBLE-TAP  screen translation     HOLD  start / stop recording',
            style: TextStyle(
              color: MatrixColors.muted,
              fontSize: 8,
              height: 1.55,
            ),
          ),
        ],
      ),
    );
  }
}

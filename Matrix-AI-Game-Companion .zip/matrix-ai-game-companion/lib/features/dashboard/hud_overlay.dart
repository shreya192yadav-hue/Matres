import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';

import '../../core/services/overlay_service.dart';
import '../../core/theme/matrix_theme.dart';

class HudOverlay extends StatefulWidget {
  const HudOverlay({super.key});

  @override
  State<HudOverlay> createState() => _HudOverlayState();
}

class _HudOverlayState extends State<HudOverlay> {
  StreamSubscription<dynamic>? _subscription;
  String _guidance = 'MATRIX';

  @override
  void initState() {
    super.initState();
    _subscription = FlutterOverlayWindow.overlayListener.listen(_onMessage);
  }

  void _onMessage(dynamic raw) {
    try {
      final decoded = raw is String ? jsonDecode(raw) : raw;
      if (decoded is Map && decoded['type'] == 'guidance') {
        final text = decoded['text']?.toString() ?? '';
        if (mounted && text.isNotEmpty) {
          setState(() => _guidance = text);
        }
      }
    } on FormatException {
      // Ignore unrelated overlay messages.
    }
  }

  Future<void> _send(OverlayAction action) =>
      FlutterOverlayWindow.shareData(OverlayAction.encode(action));

  @override
  void dispose() {
    unawaited(_subscription?.cancel());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: GestureDetector(
        onTap: () => _send(OverlayAction.voice),
        onDoubleTap: () => _send(OverlayAction.translate),
        onLongPress: () => _send(OverlayAction.record),
        child: Container(
          width: 234,
          height: 102,
          decoration: BoxDecoration(
            color: MatrixColors.background.withValues(alpha: 0.94),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(
              color: MatrixColors.neon.withValues(alpha: 0.82),
              width: 1.4,
            ),
            boxShadow: [
              BoxShadow(
                color: MatrixColors.neon.withValues(alpha: 0.34),
                blurRadius: 19,
                spreadRadius: 1,
              ),
            ],
          ),
          child: Row(
            children: [
              const SizedBox(width: 15),
              const Icon(Icons.bolt, color: MatrixColors.neon, size: 22),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  _guidance,
                  maxLines: 4,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: MatrixColors.text,
                    fontFamily: 'monospace',
                    fontSize: 9,
                    height: 1.25,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              const Icon(Icons.touch_app, color: MatrixColors.muted, size: 16),
              const SizedBox(width: 12),
            ],
          ),
        ),
      ),
    );
  }
}
